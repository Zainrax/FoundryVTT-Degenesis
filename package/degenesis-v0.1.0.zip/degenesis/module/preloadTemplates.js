export const preloadTemplates = async function () {
    const templatePaths = [
    // Add paths to "systems/degenesis/templates"
    ];
    return loadTemplates(templatePaths);
};
